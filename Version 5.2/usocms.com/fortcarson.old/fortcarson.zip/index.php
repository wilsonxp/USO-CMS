<!DOCTYPE html>

<?PHP

$cmd = $_GET['cmd'];
include ('config.php');
include ('counter.php');
include ('footer.php');
$IP = 'something from somewhere';


setcookie("IP", $ip);
setcookie("Logged", "True");
setcookie("Username", $cookie);
setcookie("Comments Disabled", $commenting_off, time()+3600);  /* expire in 1 hour */
setcookie("Visit", $date, time()+3600); //, "/~rasmus/", ".example.com", 1);
setcookie("Ref", $referer, time()+3600);

//include ('down.php');

//include('down.php'); //maintenance mode page



if ($maintenance=="true")
{
    include('maintenance.php');
    exit();
}
else
{ 
        
        if (empty($dir)) //if ?page= var empty
        {
        echo "";
        }
    else  //If ?page= var not empty
        {
        //echo 'error: Admin has been notified<br>';
        //echo 'for now you can use: <a href="',$page,'">This Link For That Page</a>';
        $host  = $_SERVER['HTTP_HOST'];
        $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        $extra = 'ul';
        header("Location: http://$host$uri/$dir"); //Include Page 
        exit();
        }

    if (!empty($_GET['page']))
    {
        $pages_dir = '../fortcarson';
        $pages = scandir($pages_dir, 0);
        unset($pages[0], $pages[1], $pages[2], $pages[4], $pages[5], $pages[8], $pages[9], $pages[10], $pages[11]);
        
        $page = $_GET['page'];
        //print_r($pages);
        //Check if Going to dynamic page
        if (in_array($page.'.php', $pages))
        {
            include ('../fortcarson/'.$page.'.php');
        }
        else
        {
            echo "!@Error: Page Does Not Exist!";
        }
    }
    else
    {
        include ('../fortcarson/menu.php');    
    }  
   
}