<?PHP
session_start();




//FOOTER
if (isset ($_SESSION['username'])) //IF A SESSION VALUE FOR USERNAME EXISTS. USER IS LOGGED IN
{
   $links="<a href='index.php?page=menu'>Food Menu</a> | <a href='index.php?page=directions'>Directions</a> | Activities | Hours of Operation | Contact Us | <a href='index.php?dir=ul'>Admin Pannel</a> | <a href='index.php?cmd=logout'>Logout</a>";
}
else //USER IS NOT LOGGED IN. REQUEST THAT USER LOGIN
{
   $links="<a style='text-decoration:none;' href='index.php?cmd=login'>*</a> <a href='index.php?page=menu'>Food Menu</a> | <a href='index.php?page=directions'>Directions</a> | Activities | Hours of Operation | Contact Us <a  style='text-decoration:none;' href='index.php?cmd=login'>*</a>";  
}


//URI CONFIG
$host  = $_SERVER['HTTP_HOST'];
$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');

if ($uri=='/fortcarson/ul') //If on Admin Dir Change Links
{
if (isset ($_SESSION['username'])) //IF A SESSION VALUE FOR USERNAME EXISTS. USER IS LOGGED IN
{
   $links="<a href='../index.php?page=menu'>Food Menu</a> | <a href='../index.php?page=directions'>Directions</a> | Activities | Hours of Operation | Contact Us | <a href='../index.php?dir=ul'>Admin Pannel</a> | <a href='../index.php?cmd=logout'>Logout</a>";
}
else //USER IS NOT LOGGED IN. REQUEST THAT USER LOGIN
{
   $links="<a style='text-decoration:none;' href='index.php?cmd=login'>*</a> <a href='index.php?page=menu'>Food Menu</a> | <a href='index.php?page=directions'>Directions</a> | Activities | Hours of Operation | Contact Us <a  style='text-decoration:none;' href='index.php?cmd=login'>*</a>";  
}
}
else
{

}



//COMMANDS

$cmd = $_GET['cmd'];
 if ($cmd=='logout')
        {
        header('Location: http://usocms.com/fortcarson/ul/logout/');
        }
        if ($cmd=='login')
        {
        header('Location: http://usocms.com/fortcarson/index.php?dir=ul');
        }