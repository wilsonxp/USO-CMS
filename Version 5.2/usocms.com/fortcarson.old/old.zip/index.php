<?php

if (empty($page))
{
include ("menu.php");
}
else
{
include ("$page.php");
}
?>