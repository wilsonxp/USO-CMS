<?PHP
include ("iplogger.php");
/*
 * -----------------INFORMATION & LICENSING-----------------
 * 
 *      AUTHOR: Christopher Sparrowgrove
 *     COMPANY: 3x Security Services (a division of 3x Security, LLC) 
 *     WEBSITE: http://3xsecurityservices.com
 *        NAME: Menu Script PHP (MSP)
 *        DATE: July 10, 2011
 *        FILE: process.foodmenu.update.php
 *    LANGUAGE: PHP Hypertext Processor (PHP)
 * DESCRIPTION: This script is for updating content in the database for the Food Menu
 *     
 *     LICENSE: Use of this script or any part in whole or otherwise partial
 *     LICENSE: is considered an agreement to these licensing terms:  
 * 
 *     LICENSE:      1.NOT FOR COMERICAL USE
 *     LICENSE: This script or any part in whole or partial is 
 *     LICENSE: NOT FOR COMMERCIAL USE OR GAIN which could include
 *     LICENSE: any gain or profit which is not used to pay for
 *     LICENSE: overhead costs of the use of any part of the MSP 
 *     LICENSE: script. This includes advertisment and other 
 *     LICENSE: non-profit gain. 
 * 
 *     LICENSE:      2.RETAIN ALL COMMENTING
 *     LICENSE: This script including all other scripts belonging 
 *     LICENSE: to the MSP family of scripts MUST RETAIN ALL COMMENTING 
 *     LICENSE: including but not limited to above author, company, 
 *     LICENSE: website, date, file, language, description, & license.
 * 
 *     LICENSE:      3.OPEN SOURCE
 *     LICENSE: This script including all parts of the MSP family 
 *     LICENSE: of scripts are an OPEN SOURCE PROJECT of which the
 *     LICENSE: community is allowed to freely share in acordince 
 *     LICENSE: with the terms of use. OPEN SOURCE means you are  
 *     LICENSE: allowed to modify or improve this script in anyway 
 *     LICENSE: without a breach in the agrement of which you are 
 *     LICENSE: agreeing to (ex. This Agreement).
 * 
 *     LICENSE:     4.DISCLAIMER & LIABILITY
 *     LICENSE: As a company, developer, or individual this script
 *     LICENSE: nor any part is affliated or endorced by any said 
 *     LICENSE: companies or orginizations of which this script was
 *     LICENSE: originaly developed for.
 *     LICENSE: This script is developed as is therefore the company
 *     LICENSE: developers, or author CAN NOT BE HELD LIABIL for any
 *     LICENSE: miss use or malfunction of this script.
 *     LICENSE: This script has been tested to work at time of release
 *     LICENSE: but as stated is provided as is with no liability to 
 *     LICENSE: the author, company, or developers. 
 *     LICENSE: If you have obtained a copy of this script from a third
 *     LICENSE: party please visit: 
 *     LICENSE: https://github.com/3xsecurityservices/Menu-Script-PHP
 *     LICENSE: to get a copy from us as it was provided from a third party.
 * 
 *     LICENSE:      5.CHANGES TO LICENSE
 *     LICENSE: This script including all scripts developed by the author
 *     LICENSE: or company may have licensing agrements and terms which
 *     LICENSE: may change at any time with or without notifacation but
 *     LICENSE: upon such changes to the terms or licinsing you might 
 *     LICENSE: be notified by REPO (include: github, google code,etc),
 *     LICENSE: by e-mail (if aplicable), by phone (if aplicable), or
 *     LICENSE: in person upon which you have 30 days to adhere to the
 *     LICENSE: changes from the date of change with or without having
 *     LICENSE: been notified or it will be considered a voluntary breach    
 *     LICENSE: of this agreement. If so you will have the inital 30 day to 
 *     LICENSE: to remove this script include all scripts developed by the 
 *     LICENSE: the author or the company.
 *     LICENSE: Non-complience may result in a lawsuit or other legal action.
 * 
 */

/* Start Configuration */

// Security Configuration
//include_once("authenticate.php");

$id=$_POST['id'];
$date=$_POST['date'];
$user=$_POST['user'];
$lunch=$_POST['lunch'];
$dinner=$_POST['dinner'];

// Include Database
include_once "database.php";

$host = 'localhost'; // Database host (probably won't change)
$db = 'fbapp'; // Database name
$user = 'root'; //Database username
$pass = 'root'; // Database password

$db_connect_error = 'Uhhhh...There\'s something wrong with the connection. Here\'s what I see: ';
$db_select_error = 'Uhhhh...There\'s something wrong with the database. Here\'s what I see: ';
$failsafe = "<?PHP header('Location: http://www.3xsecurityservices.com/uso/MSP/down.php');?>";


$con = mysql_connect($host,$user,$pass);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db($db, $con);

mysql_query("UPDATE foodmenu SET lunch = '$lunch', dinner = '$dinner'
WHERE id = '$id'");

mysql_close($con);
header("Location: foodmenu.update.php");
?>