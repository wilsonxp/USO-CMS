<?PHP
include ("iplogger.php");
/*
 * -----------------INFORMATION & LICENSING-----------------
 * 
 *      AUTHOR: Christopher Sparrowgrove
 *     COMPANY: 3x Security Services (a division of 3x Security, LLC) 
 *     WEBSITE: http://3xsecurityservices.com
 *        NAME: Menu Script PHP (MSP)
 *        DATE: July 10, 2011
 *        FILE: foodmenu.update.php
 *    LANGUAGE: PHP Hypertext Processor (PHP)
 * DESCRIPTION: This script is for updating content in the database for the Food Menu
 *     
 *     LICENSE: Use of this script or any part in whole or otherwise partial
 *     LICENSE: is considered an agreement to these licensing terms:  
 * 
 *     LICENSE:      1.NOT FOR COMERICAL USE
 *     LICENSE: This script or any part in whole or partial is 
 *     LICENSE: NOT FOR COMMERCIAL USE OR GAIN which could include
 *     LICENSE: any gain or profit which is not used to pay for
 *     LICENSE: overhead costs of the use of any part of the MSP 
 *     LICENSE: script. This includes advertisment and other 
 *     LICENSE: non-profit gain. 
 * 
 *     LICENSE:      2.RETAIN ALL COMMENTING
 *     LICENSE: This script including all other scripts belonging 
 *     LICENSE: to the MSP family of scripts MUST RETAIN ALL COMMENTING 
 *     LICENSE: including but not limited to above author, company, 
 *     LICENSE: website, date, file, language, description, & license.
 * 
 *     LICENSE:      3.OPEN SOURCE
 *     LICENSE: This script including all parts of the MSP family 
 *     LICENSE: of scripts are an OPEN SOURCE PROJECT of which the
 *     LICENSE: community is allowed to freely share in acordince 
 *     LICENSE: with the terms of use. OPEN SOURCE means you are  
 *     LICENSE: allowed to modify or improve this script in anyway 
 *     LICENSE: without a breach in the agrement of which you are 
 *     LICENSE: agreeing to (ex. This Agreement).
 * 
 *     LICENSE:     4.DISCLAIMER & LIABILITY
 *     LICENSE: As a company, developer, or individual this script
 *     LICENSE: nor any part is affliated or endorced by any said 
 *     LICENSE: companies or orginizations of which this script was
 *     LICENSE: originaly developed for.
 *     LICENSE: This script is developed as is therefore the company
 *     LICENSE: developers, or author CAN NOT BE HELD LIABIL for any
 *     LICENSE: miss use or malfunction of this script.
 *     LICENSE: This script has been tested to work at time of release
 *     LICENSE: but as stated is provided as is with no liability to 
 *     LICENSE: the author, company, or developers. 
 *     LICENSE: If you have obtained a copy of this script from a third
 *     LICENSE: party please visit: 
 *     LICENSE: https://github.com/3xsecurityservices/Menu-Script-PHP
 *     LICENSE: to get a copy from us as it was provided from a third party.
 * 
 *     LICENSE:      5.CHANGES TO LICENSE
 *     LICENSE: This script including all scripts developed by the author
 *     LICENSE: or company may have licensing agrements and terms which
 *     LICENSE: may change at any time with or without notifacation but
 *     LICENSE: upon such changes to the terms or licinsing you might 
 *     LICENSE: be notified by REPO (include: github, google code,etc),
 *     LICENSE: by e-mail (if aplicable), by phone (if aplicable), or
 *     LICENSE: in person upon which you have 30 days to adhere to the
 *     LICENSE: changes from the date of change with or without having
 *     LICENSE: been notified or it will be considered a voluntary breach    
 *     LICENSE: of this agreement. If so you will have the inital 30 day to 
 *     LICENSE: to remove this script include all scripts developed by the 
 *     LICENSE: the author or the company.
 *     LICENSE: Non-complience may result in a lawsuit or other legal action.
 * 
 */

/* Start Configuration */

//Security Configuartion
//include("authenticate.php");
//include('iplogger.php');

//MySQL Database config
//include('/config/config.php');

$host = 'localhost'; // Database host (probably won't change)
$db = 'fbapp'; // Database name
$user = 'root'; //Database username
$pass = 'root'; // Database password

$db_connect_error = 'Uhhhh...There\'s something wrong with the connection. Here\'s what I see: ';
$db_select_error = 'Uhhhh...There\'s something wrong with the database. Here\'s what I see: ';
$failsafe = "<?PHP header('Location: http://www.3xsecurityservices.com/uso/MSP/down.php');?>";

//Version Information
$Maj_Ver = "0"; 
$Min_Ver = "0";
$Build_Ver = "1-Beta1";
$Ver_Break = ".";
$Version = $Maj_Ver . $Ver_Break . $Min_Ver . $Ver_Break . $Build_Ver;

//Extra Variables
$space1x = '&nbsp;';
$space5x = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
$space32x = $space5x . $space5x . $space5x . $space5x . $space5x . $space5x;

//Date & Time Configurations
//For supported Time Zones please navigate to below address to replace default.
// http://php.net/manual/en/timezones.php

date_default_timezone_set('America/Denver'); //Default Time Zone: Mountain Time
                                             
//For help on setting up Date & Time format please navigate to below address.
//http://www.tizag.com/phpT/phpdate.php
//Edit only info inside date(" ");

$date= date("l, M d, Y"); // Default Format: Day, Month Date, Year
$time24= date(" Hi"); // Default Format is 24 Hour Time
$time12=date("(h:i:sA)"); //Default Format is 12 Hour Time
$datetime= "$date $time24 $time12"; //Display Date & Time
/* End Configuration */


?>
<!DOCTYPE html>
<html>
<head>
    <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <META ame="author" content="Christopher Sparrowgrove">
    <META name="date" content="May 17, 2011">
    <META name="company" content="3X Security Services, NLC">
    <META name="description" content="Dynamic Food Menu">
    <META name="license" content="http://services.3xsecurityservices.com/licenses.php">
    <META name="dol" content="">
    <META name="keywords" lang="en-us" content="USO, Fort Carson, 
          Christopher Sparrowgrove, winxptk, Sparrowgrove, Food Menu, 
          United Service Orginization, 3X Security, 3X Security Services">
    <META name="robots" content="index,nofollow">
    <title>USO Food Menu <?PHP echo $datetime; ?></title>

    <link type="text/css" rel="stylesheet" href="style.css" />
    
</head>
<body>

<div id="header">
    <STRONG>
          <font size="5px">
                  <?PHP echo $space32x; ?> .USO Fort Carson Food Menu.
          </font>
    </STRONG><br><br>
</div>
        
        <!-- Menu Script Pro: Start of Menu -->
    <table class="menu" cellpadding="0" cellspacing="0" width="292" 
           height="470" border="0" dir="ltr">

        <!--Menu Script Pro: Label Table -->
        <tr>
            <td class="menu" width="215" height="5" valign="top">
                <span style='font-weight:bold;'>
                    Day
                </span>
            </td>    
            <td class="menu_l" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                    <center>Lunch</center>
                </span>
            </td>
            <td class="menu_d" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                    <center>Dinner</center>
                </span>                    
            </td>
        </tr>

        <!--Menu Script Pro: Start Sunday Menu-->
        <tr>
            <td class="sunday" width="77" height="5" valign="top">
            <span style='font-weight:bold;'>
                <form action="process.foodmenu.update.php" method="POST">
                <input type="hidden" name="id" value="1">
                <input type="hidden" name="date" value="<?PHP echo $datetime; ?>">
                <input type="hidden" name="user" value="<?PHP echo $my_username; ?>">
                  <?PHP
                    $connect = mysql_connect($host, $user, $pass);
                    if (!$connect) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT day FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 0); //Output Sunday
                    echo $space1x;
                    ?>
                </span>
            </td>
            <td class="sunday_l" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="lunch" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT lunch FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 0); //Output Sunday Lunch
                    echo $space1x;
                    ?>"></center>   
                </span>
            </td>
            <td class="sunday_d" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="dinner" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT dinner FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 0); //Output Sunday Lunch
                    echo $space1x;
                    ?>"></center>    
                </span>
            </td> 
            <td>
                <input type="submit" name="submit" value="update"></form>
            </td>
        </tr>
        <!--Menu Script Pro: Start Monday Menu-->
        <tr>
            <td class="monday" width="77" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <form action="process.foodmenu.update.php" method="POST">
                <input type="hidden" name="id" value="2">
                <input type="hidden" name="date" value="<?PHP echo $datetime; ?>">
                <input type="hidden" name="user" value="<?PHP echo $my_username; ?>">
                    <?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT day FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 1); //Output Monday
                    echo $space1x;
                    ?>    
                </span>
            </td>
            <td class="monday_l" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="lunch" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT lunch FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 1); //Output Sunday Lunch
                    echo $space1x;
                    ?>"></center> 
                </span>
            </td>
            <td class="monday_d" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                 <center>
                     <input type="text" name="dinner" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT dinner FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 1); //Output Monday Dinner
                    echo $space1x;
                    ?>"></center> 
                </span>                    
            </td>
            <td>
                <input type="submit" name="submit" value="update"></form>
            </td>
        </tr>

        <!--Menu Script Pro: Start Tuesday Menu-->
        <tr>
            <td class="tuesday" width="77" height="5" valign="top">
                <span style='font-weight:bold;'>
                <form action="process.foodmenu.update.php" method="POST">
                <input type="hidden" name="id" value="3">    
                    <?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT day FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 2); //Output Tuesday
                    echo $space1x;
                    ?> 
                </span>
            </td>
            <td class="tuesday_l" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                 <center>
                     <input type="text" name="lunch" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT lunch FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 2); //Output Tuesday Lunch
                    echo $space1x;
                    ?>"></center> 
                </span>
            </td>
            <td class="tuesday_d" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="dinner" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT dinner FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 2); //Output Tuesday Dinner
                    echo $space1x;
                    ?>"></center>    
                </span>
            </td>
            <td>
                <input type="submit" name="submit" value="update"></form>
            </td>
        </tr>

        <!--Menu Script Pro:Start Wednesday Menu-->
        <tr>
            <td class="wednesday" width="77" height="5" valign="top">
                <span style='font-weight:bold;'>
                <form action="process.foodmenu.update.php" method="POST">
                <input type="hidden" name="id" value="4">
                <input type="hidden" name="date" value="<?PHP echo $datetime; ?>">
                <input type="hidden" name="user" value="<?PHP echo $my_username; ?>">
                    <?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT day FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 3); //Output Wednesday
                    echo $space1x;
                    ?>  
                </span>  
            </td>
            <td class="wednesday_l" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="lunch" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT lunch FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 3); //Output Wednesday Lunch
                    echo $space1x;
                    ?>"></center>  
                </span>
            </td>
            <td class="wednesday_d" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="dinner" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT dinner FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 3); //Output Wednesday Dinner 
                    echo $space1x;
                    ?>"></center>   
                </span>
            </td>
            <td>
                <input type="submit" name="submit" value="update"></form>
            </td>
        </tr>

        <!--Menu Script Pro: Start Thursday Menu-->
        <tr>
            <td class="thursday" width="77" height="5" valign="top">
                <span style='font-weight:bold;'>
                <form action="process.foodmenu.update.php" method="POST">
                <input type="hidden" name="id" value="5">
                <input type="hidden" name="date" value="<?PHP echo $datetime; ?>">
                <input type="hidden" name="user" value="<?PHP echo $my_username; ?>">
                    <?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT day FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 4); //Output Thursday
                    echo $space1x;
                    ?>  
                </span>
            </td>
            <td class="thursday_l" width="215" height="5" valign="top">
            <span style='font-size:8.0pt;font-family:"Courier New"'>
            <center>
                  <input type="text" name="lunch" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT lunch FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 4); //Output Thursday Lunch
                    echo $space1x;
                    ?>"></center>   
                </span>
            </td>
            <td class="thursday_d" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="dinner" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT dinner FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 4); //Output Thursday Dinner
                    echo $space1x;
                    ?>"></center>   
                </span>
            </td>
            <td>
                <input type="submit" name="submit" value="update"></form>
            </td>
        </tr>

        <!--Menu Script Pro: Start Friday Menu-->
        <tr>
            <td class="friday" width="77" height="5" valign="top">
                <span style='font-weight:bold;'>
                <form action="process.foodmenu.update.php" method="POST">
                <input type="hidden" name="id" value="6">
                <input type="hidden" name="date" value="<?PHP echo $datetime; ?>">
                <input type="hidden" name="user" value="<?PHP echo $my_username; ?>">
                    <?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT day FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 5); //Output Friday
                    echo $space1x;
                    ?>   
                </span>
            </td>
            <td class="friday_l" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                 <center>
                     <input type="text" name="lunch" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT lunch FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 5); //Output Friday Lunch
                    echo $space1x;
                    ?>"></center>   
                </span>
            </td>
            <td class="friday_d" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="dinner" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT dinner FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 5); //Output Friday Dinner
                    echo $space1x;
                    ?>"></center>   
                </span>
            </td>
            <td>
                <input type="submit" name="submit" value="update"></form>
            </td>
        </tr>

        <!--Menu Script Pro: Start Saturday Menu-->
        <tr>
            <td class="saturday" width="77" height="5" valign="top">
                <span style='font-weight:bold;'>
                <form action="process.foodmenu.update.php" method="POST">
                <input type="hidden" name="id" value="7">
                <input type="hidden" name="date" value="<?PHP echo $datetime; ?>">
                <input type="hidden" name="user" value="<?PHP echo $my_username; ?>">
                    <?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT day FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 6); //Output Saturday
                    echo $space1x;
                    ?>   
                </span>
            </td>
            <td class="saturday_l" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="lunch" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT lunch FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 6); //Output Saturday Lunch
                    echo $space1x;
                    ?>"></center>   
                </span>
            </td>
            <td class="saturday_d" width="215" height="5" valign="top">
                <span style='font-size:8.0pt;font-family:"Courier New"'>
                <center>
                    <input type="text" name="dinner" size="26" value="<?PHP
                    $link = mysql_connect($host, $user, $pass);
                    if (!$link) {
                        die('Could Not Connect: ' . mysql_error());
                    }
                    if (!mysql_select_db($db)) {
                        die('Database Error: ' . mysql_error());
                    }

                    $results = mysql_query('SELECT dinner FROM foodmenu');
                    if (!$results) {
                        die('Bad Query: ' . mysql_error());
                    }
                    echo mysql_result($results, 6); //Output Saturday Dinner
                    echo $space1x;
                    ?>"></center>  
                </span>
            </td>
            <td>
                <input type="submit" name="submit" value="update"></form>
            </td>
        </tr>
    </table>
    <div id="footer3">
        <?PHP 
          ECHO "Version: ", $Version;
          ?>
    <?PHP include ('/loginfooter.php'); ?>
        <font id="license">This work is licensed under a 
    <a rel="license" 
       href="http://services.3xsecurityservices.com/licenses.php?license=uso">
        NonCommercial - Open Source License</a></font>
    </div>
    <div id="fb_like">
        <iframe src="http://www.facebook.com/plugins/like.php?href=http://3xsecurityservices.com"
        scrolling="no" frameborder="0" allowtransparency="true"
        style="border:none; width:0px; height:0px"></iframe>
    </div>
</body>
</html>